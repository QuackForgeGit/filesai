# Card image black-gap fix

## What I found reading z.ai's code
`src/components/card-section.tsx` had the card image set to
`object-fit: contain` inside a fixed-size container (280×460 mobile,
340×560 desktop — a ~0.61 width:height ratio). Your 9 frame images are
`1086×1448` (≈0.75 ratio) for six of them and `1024×1536` (≈0.665 ratio)
for the other four (Titan + all 3 keys). `contain` guarantees the whole
image stays visible with nothing cropped — which necessarily means empty
space wherever the container's ratio doesn't match the image's, and
neither image ratio matched the container at all. That's the black
top/bottom/corner gaps you circled.

## Why code alone couldn't fully fix it
I checked: there's barely any actual empty margin inside your images to
crop away (1–14px at most — your art already fills basically the entire
canvas). The two groups are just genuinely different shapes because
they were generated as different canvas sizes. So there's no "excess" to
crop — the fix has to either crop into real artwork (not acceptable) or
add space, not remove it.

## What I did
Padded (never cropped) the 4 mismatched images with transparent space on
the left/right until every one of the 9 images shares the **exact same
1086×1448 canvas** — full art preserved, zero pixels of actual artwork
touched. Then fixed the card container in `card-section.tsx` to match
that same 0.75 ratio (300×400 mobile, 360×480 desktop) instead of the old
mismatched 0.61 ratio. With image and container now sized identically,
there's nothing left to gap — checked this by screenshotting both a
group-A card (VIP) and the previously-broken group-B card (Titan) side by
side, both flush edge-to-edge, no black anywhere.

## Bonus: image weight
While I was in there — the frame images were the *original uncompressed
uploads*, sitting in `public/frames/` as raw PNGs averaging ~2.8MB each
(25MB total for 9 card images, which is a lot for a page people load on
mobile data). Resized to actual display resolution and converted to
WebP: **25MB → 1.3MB**, same visual quality at the size they're actually
shown on screen.

## How to apply
Copy `public/frames/*.webp` over the existing (now-removed) `.png`
originals, and replace `src/components/card-section.tsx` and
`src/app/store/page.tsx` with the versions here (the only page.tsx change
is updating the `frame:` paths from `.png` to `.webp`).
