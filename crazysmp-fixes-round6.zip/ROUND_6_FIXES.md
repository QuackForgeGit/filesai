# Round 6: desktop backgrounds + site-wide scrolling background

## New images (renamed as requested)
- `front-bg-mobile.webp` — your portrait night-scene image, used as the
  site-wide background on phones
- `front-bg-desktop.webp` — the wide version of the same scene, used on
  desktop (≥900px)
- `login-bg-desktop.webp` — the wide login-page composition, used for the
  desktop login screen

## 1. Main site background is now full-page and persistent
Before, the background image only lived in the hero strip at the top —
everything below it was flat `#141019`. Now there's a single `position:
fixed` background layer behind the *entire* page (swapped mobile↔desktop
at the 900px breakpoint via a CSS media query, same pattern as everywhere
else in this project), with all page content sitting in a `position:
relative` layer on top of it.

## 2. Scroll-driven blur + darken
A second fixed layer sits directly above the background image and uses
`backdrop-filter: blur()` plus an increasingly-opaque dark tint, both
driven by scroll position (0 at the top, ramping up by the bottom).
Driven straight through a ref in a scroll listener rather than React
state, so it doesn't cause a re-render on every scroll tick — stays
smooth. Tested at the top, middle, and bottom of the page: sharp and
lightly tinted at the top, progressively softer and darker going down,
nearly the same solid "black shade" look the old hero had at its bottom
by the time you reach the footer — same effect, now sustained across the
whole page instead of just the hero.

## 3. Desktop login — real background art instead of the gradient placeholder
Swapped the placeholder purple/blue gradient card for your actual
`login-bg-desktop.webp`, using **contain**-fit (shrinks/grows to fit the
available space, never crops) instead of the cover-crop approach used on
mobile — matches what you asked for specifically for desktop. Added a
glowing border frame around the image so the letterboxed edges (which
show up on unusually short or unusually wide windows) read as an
intentional frame rather than a cut-off.

Re-measured the three interactive boxes from scratch against this new
image (completely different composition/ratio from the mobile one, so
the old coordinates wouldn't have applied) using the same pixel-precision
color-sampling method as every other login fix in this project. Tested
across three very different window shapes — 1440×900, 1920×1080, and a
short/wide 1024×900 that forces heavy letterboxing — boxes stayed
pixel-correct on the art in all three.

Caught one bug before calling it done: my first pass added a Steve-face
avatar icon next to the username field, not realizing your artwork
already has one baked in — ended up with two overlapping faces. Fixed by
removing the duplicate and just offsetting the input, matching how the
mobile version already handles it.

Also tested the actual login flow on desktop end-to-end: typed a
username, toggled Bedrock (dot appears correctly), hit Continue —
redirects to `/store` with the username saved.

## How to apply
Copy the 3 images into `public/`, and replace `src/app/login/page.tsx`
and `src/app/store/page.tsx` with the versions here.
