# Round 3 fixes for crazysmp-website

## 1. Login was a fixed overlay → now a real page (`/login`)
The old `FullScreenLogin` was a `position: fixed` div layered on top of the
home page. On mobile, fixed overlays are notoriously leaky about scroll —
even with `overflow: hidden` on the overlay itself, the underlying `body`
can still scroll underneath it (what you were seeing: scrolling the "login
overlay" and the actual store content behind it moving). GLM's earlier
attempts (dvh sizing, overflow:hidden on the modal div) didn't touch the
real cause, which is body-level scroll, not the modal's own scroll.

Converted it into an actual Next.js route: `src/app/login/page.tsx`.
Clicking your name/avatar now does `router.push("/login")` — a real
navigation, new URL, no leftover page underneath to scroll into. I also
locked `html`/`body` overflow on that page as a belt-and-suspenders measure.
Tested in a real browser: scrolling the login page now measurably does
nothing (`window.scrollY` stays `0`, `body.scrollHeight` exactly equals
viewport height).

Submitting now writes the username to `localStorage` and navigates back to
`/`, which reads it back on mount — so "logged in" state survives the page
change same as before, it just does it via a real redirect instead of
component state.

## 2. Black letterbox bars → blurred continuation of the same image
The login artwork is a fixed 450:800 image. Whenever a screen's aspect
ratio doesn't match that exactly, `object-fit: contain` was leaving flat
`#0F0F13`-near-black bars in the gap. Added a second, blurred, scaled-up
copy of the same image as a backdrop layer behind the sharp one — so any
gap is filled with a soft continuation of the art instead of a hard black
edge (the effect Spotify/YouTube use for mismatched aspect ratios).
Verified visually at a squarer viewport where the gap is large — no more
visible black bar.

## 3. Desktop was just a cropped phone view → real responsive layout
Root cause: the whole page had `maxWidth: 480` hardcoded with no
breakpoint, and the hero's background image is the phone-ratio artwork
stretched with `background-size: cover` — on a wide short desktop viewport
that crops it down to an unrecognizable sliver of the middle of the image.

Added a `900px` breakpoint:
- Root container widens to `1200px` instead of staying pinned at `480px`.
- Hero and login backgrounds swap to a hand-built purple/blue gradient
  (`radial-gradient` glow + dark base) instead of trying to force the
  phone-ratio photo to cover a wide viewport. You said you'll send a proper
  desktop-ratio background later — this is a placeholder until then, not a
  redesign of the art direction.
- Featured Packages becomes a responsive grid (up to 3 columns) instead of
  one long mobile column.
- The login page gets a genuinely separate desktop layout: a centered
  card with your actual logo (that one's not phone-ratio, so it's used
  as-is), a real styled input and Continue button — not the mobile
  image-overlay approach, since there's no image to overlay on desktop.

Mobile (< 900px) is untouched pixel-for-pixel — verified this at 480px and
899px viewports, both still show the exact original mobile design.

## 4. Discord FAB
Didn't touch it — it's solid (already does its own proper body-scroll-lock
while its popup is open, which is the same technique I used for `/login`).
It only renders on the home page, so it's unaffected by the login-page
change.

## 5. Pricing
Updated all 6 ranks:

| Rank     | Old   | New  |
|----------|-------|------|
| VIP      | ₹199  | ₹29  |
| LEGEND   | ₹399  | ₹69  |
| IMMORTAL | ₹699  | ₹119 |
| TITAN    | ₹999  | ₹179 |
| TECHNO   | ₹1499 | ₹239 |
| CRAZY    | ₹2499 | ₹299 |

Key prices (Spawner/Mega/Crazy Key) weren't mentioned, left as-is.

## How to apply
- `src/app/login/page.tsx` is a **new file** — add it at that exact path.
- `src/app/page.tsx` — replace your existing file with this one, or
  `git apply page-diff.patch` from your repo root.
