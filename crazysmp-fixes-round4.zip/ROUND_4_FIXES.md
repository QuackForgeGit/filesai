# Round 4 fixes for crazysmp-website

## 1. Bedrock toggle position/design
The version you screenshotted had a giant red box with an X icon sitting
half-off the green bar — that was a broken placeholder, not a real toggle.
Replaced it with an actual small pill switch on the right side of the bar
(green/glowing when on, grey when off, knob slides). Same treatment added
to the desktop login card too, which didn't have a Bedrock option at all
before.

## 2. Login background not fully covering the screen
The previous attempt used `object-fit: contain` with a solid black
backdrop, which is exactly why you were seeing ~0.5cm bars top and bottom —
`contain` guarantees the whole image is visible, which necessarily means
gaps unless the container's aspect ratio happens to exactly match the
image's.

Rebuilt this properly: I now measure the actual viewport in JS and compute
the same crop math the CSS `cover` keyword uses (scale up until both
dimensions are filled, crop the overflow), then position the interactive
boxes using that exact same transform. So the background is a true
edge-to-edge crop/zoom — no blur, no letterbox, no black bars — and the
username/toggle/continue boxes still land pixel-correct on top of it no
matter the device's aspect ratio. Tested this at several different
viewport ratios (tall-narrow, wide-ish, standard) — full bleed every time.

Also re-measured the box coordinates from scratch against your new
higher-res `LoginBG.png`, since it's not pixel-identical to the old one.

Hit one sneaky bug while building this: Tailwind's preflight CSS sets
`img { max-width: 100% }`, which was silently clamping my explicit width
even though it was set inline. Fixed by adding `maxWidth: "none"`.

## 3. Close (X) button position
This was already fixed as a side effect of removing the experimental
"visual editor" mode in your last commit — the button sits cleanly
top-right now. Confirmed with a screenshot.

## 4. New rank/key/logo images + "crystals sticking out" effect
Swapped in all 9 new logo images, the new CrazySMP logo, and the new login
background. Auto-cropped each to its tight alpha bounding box (removes any
excess transparent canvas) and converted everything to WebP — cut the
total image weight from ~2.8MB down to ~950KB combined.

Changed how icons render: instead of forcing every logo into a fixed
square with `object-fit: cover` (which either crops wide logos or leaves
empty space, depending on the source image's own padding), icons now size
by **height only** — they always fill the box's full height, and since
your art is wider than it is tall, it naturally bleeds a little past the
nominal footprint on both sides. That's the "crystals sticking out" effect
you asked for, and it happens automatically rather than needing a special
case per image.

One thing I had to walk back: my first pass bled the widest logos (VIP,
Techno) far enough to actually cover the "VIP Rank" title text. Fixed by
reducing the icon size and widening the gap between icon and text — re-
checked every single card afterward, no more overlaps anywhere.

## On your GitHub PAT offer
Yes — a short-lived, narrowly-scoped token is exactly the right call here,
and yes I can use it (github.com/api.github.com are in my network
allowlist). Concretely I'd suggest:
- Fine-grained PAT (not classic), scoped to just this one repository
  (`StXaviersOfficial/crazysmp-website`)
- Permission: **Contents — Read and write** only (that's all pushing
  commits needs)
- Shortest expiration GitHub lets you pick (fine-grained tokens go down to
  1 day)
- Revoke it the moment I'm done — I don't retain it between conversations
  anyway, so there's no downside to killing it immediately.
If you'd rather keep the zip-file workflow, that's completely fine too —
whichever's easier for you.

## How to apply
Copy `public/*` and `src/app/login/page.tsx` + `src/app/store/page.tsx`
from this folder over your existing files (same paths). You can delete
the old `pkg-*.png`, `store-logo-new.webp` (old version), and
`login-bg.png` — they're no longer referenced anywhere.
