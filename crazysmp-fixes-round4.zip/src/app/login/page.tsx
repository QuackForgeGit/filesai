"use client";

import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { X } from "lucide-react";

const LOGIN_BG = "/login-bg.webp";
const LOGO = "/store-logo-new.webp";
const MC = "'Minecraft', 'Inter', monospace";

// Intrinsic size of login-bg.webp — used to compute exact cover-fill math
// below (not just for display, so don't change without re-measuring).
const NATURAL_W = 941;
const NATURAL_H = 1672;

// Box coordinates measured directly from login-bg.webp via pixel color
// sampling (percentage of the ORIGINAL image, not of any container) —
// these get mapped into actual on-screen pixels by the cover-fit math.
const BOX1 = { left: 15.73, top: 55.32, width: 69.08, height: 7.0 }; // username
const BOX2 = { left: 15.73, top: 64.95, width: 69.08, height: 5.74 }; // bedrock toggle
const BOX3 = { left: 15.73, top: 72.49, width: 69.08, height: 7.36 }; // continue

// Only letters, digits, and underscore are valid Minecraft username chars.
// A leading dot (added by the Bedrock toggle, for GeyserMC) is preserved.
const sanitize = (raw: string, keepDot: boolean) => {
  const hasDot = keepDot && raw.startsWith(".");
  const rest = raw.replace(/^\./, "").replace(/[^A-Za-z0-9_]/g, "").slice(0, 16);
  return (hasDot ? "." : "") + rest;
};

// Maps a box given in ORIGINAL-IMAGE percentages into actual on-screen
// pixels, given how the image is currently being cover-cropped to fill
// the viewport. This is what makes the overlays land exactly on the
// artwork's boxes regardless of device aspect ratio, with the background
// fully covering the screen (crop instead of letterbox/blur).
function mapBox(box: { left: number; top: number; width: number; height: number }, fit: { renderedW: number; renderedH: number; offsetX: number; offsetY: number }) {
  return {
    left: fit.offsetX + (box.left / 100) * fit.renderedW,
    top: fit.offsetY + (box.top / 100) * fit.renderedH,
    width: (box.width / 100) * fit.renderedW,
    height: (box.height / 100) * fit.renderedH,
  };
}

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [bedrock, setBedrock] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [fit, setFit] = useState<{ renderedW: number; renderedH: number; offsetX: number; offsetY: number } | null>(null);

  // Recompute the cover-fit (crop-to-fill) transform whenever the viewport
  // size changes, so the background always fully covers the screen — no
  // letterbox gaps, no blur fill needed — and the interactive boxes track
  // exactly with wherever the artwork ends up.
  useEffect(() => {
    const compute = () => {
      const el = containerRef.current;
      if (!el) return;
      const cw = el.clientWidth;
      const ch = el.clientHeight;
      const scale = Math.max(cw / NATURAL_W, ch / NATURAL_H);
      const renderedW = NATURAL_W * scale;
      const renderedH = NATURAL_H * scale;
      setFit({
        renderedW,
        renderedH,
        offsetX: (cw - renderedW) / 2,
        offsetY: (ch - renderedH) / 2,
      });
    };
    compute();
    window.addEventListener("resize", compute);
    window.visualViewport?.addEventListener("resize", compute);
    return () => {
      window.removeEventListener("resize", compute);
      window.visualViewport?.removeEventListener("resize", compute);
    };
  }, []);

  // If the person already has a saved username, prefill it so this reads
  // as "edit" rather than a blank login.
  useEffect(() => {
    const saved = typeof window !== "undefined" ? localStorage.getItem("crazysmp_username") : null;
    if (saved) {
      if (saved.startsWith(".")) {
        setBedrock(true);
        setUsername(saved.replace(/^\./, ""));
      } else {
        setUsername(saved);
      }
    }
  }, []);

  const goBack = () => router.push("/store");

  const toggleBedrock = () => {
    setBedrock((prev) => {
      const next = !prev;
      setUsername((u) => {
        const bare = u.replace(/^\./, "");
        if (!next) return bare;
        return u.startsWith(".") ? u : `.${bare}`;
      });
      return next;
    });
  };

  const handleSubmit = () => {
    const clean = username.trim();
    if (!clean || clean === ".") return;
    localStorage.setItem("crazysmp_username", clean);
    router.push("/store");
  };

  const box1 = fit ? mapBox(BOX1, fit) : null;
  const box2 = fit ? mapBox(BOX2, fit) : null;
  const box3 = fit ? mapBox(BOX3, fit) : null;

  return (
    <div style={{ position: "fixed", inset: 0, overflow: "hidden", background: "#0a0612" }}>
      <style>{`
        @import url('https://fonts.cdnfonts.com/css/minecraft-4');
        html, body { overflow: hidden !important; height: 100%; overscroll-behavior: none; }
        .csmp-login-mobile { display: block; }
        .csmp-login-desktop { display: none; }
        @media (min-width: 900px) {
          .csmp-login-mobile { display: none; }
          .csmp-login-desktop { display: flex; }
        }
        .csmp-login-input::placeholder { color: rgba(255,255,255,0.35); }
        .csmp-login-continue:active { transform: scale(0.97); }
        .csmp-toggle-track { transition: background 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease; }
        .csmp-toggle-knob { transition: transform 0.2s ease; }
      `}</style>

      <button
        onClick={goBack}
        style={{
          position: "fixed",
          top: 20,
          right: 20,
          background: "rgba(255,255,255,0.12)",
          border: "1px solid rgba(255,255,255,0.25)",
          borderRadius: 50,
          width: 40,
          height: 40,
          color: "rgba(255,255,255,0.75)",
          cursor: "pointer",
          zIndex: 20,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        aria-label="Close"
      >
        <X size={20} />
      </button>

      {/* ============ MOBILE: background is cropped to fully cover the ============ */}
      {/* ============ screen (no letterbox, no blur) — overlays are    ============ */}
      {/* ============ positioned by measuring the actual crop live.    ============ */}
      <div className="csmp-login-mobile" ref={containerRef} style={{ position: "absolute", inset: 0, overflow: "hidden" }}>
        {fit && (
          <img
            src={LOGIN_BG}
            alt="Login"
            style={{
              position: "absolute",
              left: fit.offsetX,
              top: fit.offsetY,
              width: fit.renderedW,
              height: fit.renderedH,
              maxWidth: "none",
              maxHeight: "none",
              display: "block",
            }}
          />
        )}

        {/* Username box — entire box clickable */}
        {box1 && (
          <div
            style={{ position: "absolute", left: box1.left, top: box1.top, width: box1.width, height: box1.height, display: "flex", alignItems: "center", cursor: "text", zIndex: 3 }}
            onClick={(e) => { const input = e.currentTarget.querySelector("input"); if (input) input.focus(); }}
          >
            <input
              value={username}
              onChange={(e) => setUsername(sanitize(e.target.value, bedrock))}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              placeholder="Username"
              maxLength={16}
              style={{
                width: "100%",
                height: "70%",
                marginLeft: "19%",
                paddingRight: "6%",
                background: "transparent",
                border: "none",
                outline: "none",
                color: "#fff",
                fontFamily: MC,
                fontWeight: 400,
                fontSize: 16,
                letterSpacing: 0.5,
                caretColor: "#a855f7",
              }}
            />
          </div>
        )}

        {/* Bedrock toggle — whole bar toggles it, plus a real pill switch on the right */}
        {box2 && (
          <div
            style={{ position: "absolute", left: box2.left, top: box2.top, width: box2.width, height: box2.height, display: "flex", alignItems: "center", cursor: "pointer", zIndex: 3 }}
            onClick={toggleBedrock}
          >
            <div
              className="csmp-toggle-track"
              style={{
                marginLeft: "80%",
                width: "15%",
                aspectRatio: "2 / 1",
                borderRadius: 999,
                background: bedrock ? "linear-gradient(90deg,#0f9b6a,#34d399)" : "rgba(255,255,255,0.15)",
                border: bedrock ? "1px solid rgba(74,222,128,0.85)" : "1px solid rgba(255,255,255,0.35)",
                boxShadow: bedrock ? "0 0 10px rgba(52,211,153,0.7)" : "none",
                position: "relative",
                flexShrink: 0,
              }}
            >
              <div
                className="csmp-toggle-knob"
                style={{
                  position: "absolute",
                  top: "10%",
                  left: "8%",
                  height: "80%",
                  aspectRatio: "1 / 1",
                  borderRadius: "50%",
                  background: "#fff",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.4)",
                  transform: bedrock ? "translateX(95%)" : "translateX(0%)",
                }}
              />
            </div>
          </div>
        )}

        {/* Continue box — entire box clickable */}
        {box3 && (
          <button
            onClick={handleSubmit}
            disabled={!username.trim()}
            style={{
              position: "absolute",
              left: box3.left,
              top: box3.top,
              width: box3.width,
              height: box3.height,
              background: "transparent",
              border: "none",
              cursor: username.trim() ? "pointer" : "default",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 3,
            }}
          >
            <span
              style={{
                fontFamily: MC,
                fontSize: 22,
                fontWeight: 700,
                color: "#fff",
                letterSpacing: 3,
                textShadow: "0 0 6px #fff, 0 0 16px #e879f9, 0 0 28px #c026d3, 0 0 42px #a21caf",
                opacity: username.trim() ? 1 : 0.55,
                display: "inline-block",
              }}
            >
              CONTINUE
            </span>
          </button>
        )}
      </div>

      {/* ============ DESKTOP: no phone-ratio background yet, so a hand-made ============ */}
      {/* ============ purple/blue gradient + a proper redesigned card ============ */}
      <div
        className="csmp-login-desktop"
        style={{
          position: "absolute",
          inset: 0,
          alignItems: "center",
          justifyContent: "center",
          backgroundImage:
            "radial-gradient(circle at 22% 18%, rgba(124,58,237,0.38), transparent 55%), radial-gradient(circle at 82% 78%, rgba(37,99,235,0.32), transparent 55%), linear-gradient(160deg, #1a1025 0%, #150d24 45%, #0a0812 100%)",
        }}
      >
        <div
          style={{
            width: 420,
            maxWidth: "90vw",
            background: "rgba(20,14,28,0.75)",
            border: "1px solid rgba(168,85,247,0.35)",
            borderRadius: 24,
            padding: "40px 36px",
            boxShadow: "0 0 60px -10px rgba(147,51,234,0.45), 0 20px 60px rgba(0,0,0,0.5)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <img src={LOGO} alt="CrazySMP" style={{ width: "70%", maxWidth: 220, marginBottom: 8 }} />
          <h1
            style={{
              fontFamily: MC,
              fontSize: 28,
              fontWeight: 700,
              color: "#fff",
              letterSpacing: 4,
              margin: "8px 0 28px",
              textShadow: "0 0 8px #fff, 0 0 20px #e879f9, 0 0 36px #a21caf",
            }}
          >
            LOGIN
          </h1>

          <div
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              gap: 12,
              background: "rgba(10,8,16,0.6)",
              border: "1.5px solid rgba(168,85,247,0.5)",
              borderRadius: 12,
              padding: "4px 16px",
              marginBottom: 16,
              boxShadow: "0 0 16px rgba(168,85,247,0.15) inset",
            }}
          >
            <img src="/steve-face.png" alt="" style={{ width: 30, height: 30, borderRadius: 6, flexShrink: 0 }} />
            <input
              className="csmp-login-input"
              value={username}
              onChange={(e) => setUsername(sanitize(e.target.value, bedrock))}
              onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
              placeholder="Username"
              maxLength={16}
              style={{
                flex: 1,
                minWidth: 0,
                height: 52,
                background: "transparent",
                border: "none",
                outline: "none",
                color: "#fff",
                fontFamily: MC,
                fontSize: 16,
                letterSpacing: 0.5,
                caretColor: "#a855f7",
              }}
            />
          </div>

          {/* Bedrock toggle row (desktop) */}
          <div
            onClick={toggleBedrock}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              background: "rgba(10,8,16,0.6)",
              border: "1.5px solid rgba(74,222,128,0.35)",
              borderRadius: 12,
              padding: "10px 16px",
              marginBottom: 20,
              cursor: "pointer",
            }}
          >
            <span style={{ fontFamily: MC, fontSize: 13, color: "rgba(255,255,255,0.75)", letterSpacing: 0.5 }}>BEDROCK ACCOUNT</span>
            <div
              className="csmp-toggle-track"
              style={{
                width: 40,
                height: 20,
                borderRadius: 999,
                background: bedrock ? "linear-gradient(90deg,#0f9b6a,#34d399)" : "rgba(255,255,255,0.15)",
                border: bedrock ? "1px solid rgba(74,222,128,0.85)" : "1px solid rgba(255,255,255,0.35)",
                boxShadow: bedrock ? "0 0 10px rgba(52,211,153,0.7)" : "none",
                position: "relative",
                flexShrink: 0,
              }}
            >
              <div
                className="csmp-toggle-knob"
                style={{
                  position: "absolute",
                  top: 2,
                  left: 2,
                  height: 14,
                  width: 14,
                  borderRadius: "50%",
                  background: "#fff",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.4)",
                  transform: bedrock ? "translateX(20px)" : "translateX(0px)",
                }}
              />
            </div>
          </div>

          <button
            className="csmp-login-continue"
            onClick={handleSubmit}
            disabled={!username.trim()}
            style={{
              width: "100%",
              background: username.trim() ? "linear-gradient(135deg,#a855f7,#c026d3)" : "rgba(255,255,255,0.08)",
              border: "none",
              borderRadius: 12,
              padding: "16px",
              cursor: username.trim() ? "pointer" : "default",
              boxShadow: username.trim() ? "0 0 24px rgba(192,38,211,0.5)" : "none",
              transition: "transform 0.15s ease",
            }}
          >
            <span
              style={{
                fontFamily: MC,
                fontSize: 18,
                fontWeight: 700,
                color: "#fff",
                letterSpacing: 3,
                opacity: username.trim() ? 1 : 0.45,
              }}
            >
              CONTINUE
            </span>
          </button>

          <p style={{ fontFamily: MC, fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 18, textAlign: "center", lineHeight: 1.6 }}>
            Desktop background art is on the way — using a placeholder gradient for now.
          </p>
        </div>
      </div>
    </div>
  );
}
