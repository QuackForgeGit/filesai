# AI provider limits & router facts (researched 2026-09-30)

Sources are web results, not our own measurements, unless marked MEASURED. Providers change these often:
re-check before relying on any number. Confidence: H = official doc seen, M = several third-party pages agree, L = conflicting / unofficial.

| Provider | Free limit | Scope | Conf. |
|---|---|---|---|
| Groq (gpt-oss-120b/20b, qwen3.8-27b) | 30 req/min, 1,000 req/day, **8,000 tokens/min, 200,000 tokens/day** | **per organisation (account), per model** - extra KEYS in one account add nothing; 5 accounts = 5 pools (ToS risk) | H (console.groq.com/docs/rate-limits) |
| Groq TPM billing | the 8k TPM window is charged for the `max_tokens` you DECLARE, not what is generated | - | M (MEASURED by a third party, dev.to, 2026-09) |
| OpenRouter `:free` | 20 req/min; **50 req/day** until the account has EVER bought $10 of credits, then **1,000 req/day**; the daily cap is shared by all free models | per account | H/M (OpenRouter help centre updated 2026-09-23; one aggregator still says 200/day, outdated) |
| Cloudflare Workers AI | 10,000 neurons/day, resets 00:00 UTC, shared by all models | per account | H (developers.cloudflare.com pricing) |
| Gemini API | Google no longer publishes a table. Reports for Sep 2026: **gemini-3.8-flash ~20 req/day**, 3.1-flash-lite ~500 req/day; older pages say 1,500/day (outdated). RPD resets midnight Pacific. | per **project** and model | **L** - read the live numbers in AI Studio |

## Neuron cost (Cloudflare pricing page)
| Model | in / out neurons per 1M tokens | ~output tokens per 10k neurons |
|---|---|---|
| @cf/zai-org/glm-4.7-flash | 5,500 / 36,400 | ~270k |
| @cf/openai/gpt-oss-120b | 31,818 / 68,182 | ~100-147k |
Kimi K2.6, GLM 5.x, DeepSeek V4 are Workers Paid only. Llama-3.3-70b-fp8-fast is dearer per token; the router only uses it if you add it to a ladder.

## Model IDs checked (all exist as of 2026-09-30)
Groq: openai/gpt-oss-120b, openai/gpt-oss-20b, qwen/qwen3.8-27b (llama-3.3-70b is retired).
OpenRouter: qwen/qwen3.8-27b:free, google/gemma-4-31b-it:free, google/gemma-4-26b-a4b-it:free, nvidia/nemotron-3-super-120b-a12b:free, nvidia/nemotron-3-ultra-550b-a55b:free. Removed: inclusionai/ling-3.0-flash-sante:free (exists but unrated; no reason to spend scarce daily requests on it).
Cloudflare: @cf/zai-org/glm-4.7-flash, @cf/openai/gpt-oss-120b (both on the free plan).
Gemini: gemini-3.8-flash (owner-verified live 2026-09-26). **gemini-3.1-flash-lite is UNVERIFIED as an API id** (may need a suffix): a wrong id 404s and the router just moves to the next id in the ladder. Fix without redeploy via ROUTER_LADDER_JSON.

## What the numbers mean for XavierDrive
- Groq free is ~1 fair request per minute per account once a research prompt (~6k tokens) is included; it is a burst-only provider. Before step 7 every research answer sent 4096 declared `max_tokens` on top of the prompt and was rejected with 413, which also tripped the 10-minute circuit breaker for ALL users. Fixed (see NEXT_AI_README, step 7).
- OpenRouter: 5 accounts x 50 = 250 requests/day school-wide. ONE account with a one-time $10 purchase = 1,000/day and removes the multi-account ToS risk. Set OR_FREE_DAILY=1000 after buying.
- Workers AI glm-4.7-flash is the best free pool per account (~270k output tokens/day), hence "lite" traffic goes there first.
- Gemini free is too small to be a main provider (and image questions need it): flash-lite is used for images below 'pro'.
