# ZAI_README.md - for z.ai (the manager with the terminal)

You (z.ai) get the FINAL zip. Other AIs (Claude etc.) write code in steps WITHOUT a compiler or device; you are
the one who builds, verifies, deploys and uploads. Read NEXT_AI_README.md sections 0-3 for the project and the
full wish list. This file is your running checklist and is updated every step.

## Where we are: steps 1-7 of 8 done (see NEXT_AI_README.md section 3)
Repos: app = https://github.com/StXaviersOfficial/stxaviers-android (main, v1.1.6 code 19)
       web/worker/backend = https://github.com/StXaviersOfficial/xavier-drive

## A. How to apply
1. Clone stxaviers-android main. Copy the folder changed-files/ over the repo root (paths already match:
   src/..., res/...), OR `git apply steps-1-7.patch` (same content as the old steps-1-6; step 7 has no app changes). Patch was produced against v1.1.6 main.
2. Run build-apk.sh. FIX ANY COMPILE ERRORS (none of this code has been compiled - no Android SDK was available
   to the author; it was only parse-checked, and resource references were cross-checked).
   Most likely trouble spots: AiActivity.showPlusMenu() (new bottom-sheet Dialog), rebuildDrawer(),
   showChatMenu(), new class WaveformView. Do NOT change behaviour while fixing; just make it compile.
3. Do NOT bump the version yet (final step does 1.1.7 / 20).
4. Do not upload/release until the last step is done, unless the owner asks for an interim build.

## B. On-device verification checklist (steps 1-3)
Step 1: [ ] Keyboard bottom-right key inserts a new line and never sends.  [ ] Box grows up to ~8 lines then scrolls.
        [ ] Type "hello", tap mic, speak, stop: result is "hello <spoken words>" (nothing lost).
Step 2: [ ] "+" opens a bottom sheet: Camera, Photos, Files, Generate image (admins/devs only), Deep research;
        Camera/Photos/Files still attach correctly; Deep research/Generate image show a tick when active.
        [ ] Mic turns into a blue circle with animated bars while listening, returns to the mic icon when stopped.
        [ ] Send arrow: grey when empty, blue with text/attachment; tapping sends.
Step 3: [ ] Drawer shows Pinned/Today/Yesterday/Previous 7 days/Older sections, title-only rows, 3-dot at the far right.
        [ ] 3-dot popup: Rename, Pin/Unpin, Summarize for a STUDENT; plus Delete for Teacher/Admin/Developer.
        [ ] Popup stays on screen for the last row (flips above).  [ ] Rename persists after restart.
        [ ] Pinned chats float to the top.  [ ] Dark mode looks right for all of the above.

## C. SERVER WORK for you (worker.js / xavier-drive repo) - CRITICAL
1. worker.js `DELETE /drive/delete?id=` (around line 833): any logged-in user - including students - can delete
   ANY Drive file id, because it uses the owner's Drive token and has no role or ownership check. The app only
   hides the button. Fix: in handleDrive, after `driveSess`, call verifyRole(env, driveSess.email) (line ~2253;
   check the session object's email field name) and return 403 unless role is teacher/admin/developer.
   Better: also refuse ids that are not inside the caller's chats folder (chats/{gmail}/...) or a folder a
   teacher is allowed to manage. Check the website (index.html) for any student flow that legitimately deletes
   before tightening. Deploy with wrangler and test with a student cookie: expect 403.
2. Later steps will add Worker changes (step 4 system-prompt copy-box rule, step 6 streaming events, step 7 model
   router). This file will list each one when it is written. Do not deploy Worker changes from steps 4+ until
   the same step's app code has been built and tested, because the app and Worker must be released together.

## D. Owner-side blockers still open (tell the owner)
- Groq keys are dead (OpenRouter fallback is doing the work). - OAuth consent screen is in Testing mode
  (100 users cap, 7-day refresh expiry) -> publish it. - YouTube API key renewal. - Firebase service account.
- 5 free accounts per provider is a Terms-of-Service ban risk.
- Owner decision pending: should students see "Generate image" in the + sheet? (currently admin/dev only;
  one line to change, marked in NEXT_AI_README.md section 4.)

## E. Update protocol
Each step's author appends to sections A-C. When all 8 steps are done: bump 1.1.7/code 20 in AndroidManifest.xml
and build-apk.sh, build, run the full checklist, deploy Worker, upload, release through the normal pipeline.


---
## STEP 4 UPDATE
Step 4 is done in code (see NEXT_AI_README.md, "STEP 4 — DONE"). Worker changes are in `server/` and are NOT deployed; apply after the APK is device-tested. `changed-files/` is cumulative for steps 1-4.


---
## STEP 5 UPDATE
Step 5 is done in code (see NEXT_AI_README.md, "STEP 5 - DONE"). `changed-files/` is cumulative for steps 1-5; patch is `steps-1-5.patch`
(checked with `git apply --check` against repo main). No Worker changes in this step. Do not bump the version yet.
Build: expect no new compile errors from step 5 (AiActivity/Ui compiled clean against android-34 with stubs); still run build-apk.sh.

**On-device checklist (step 5)**
[ ] "+" > Photos/Camera: a 64dp rounded square appears with a black X badge top-right; add 3-4 more and each lands on the right,
    strip scrolls to show the newest. X removes only that one.
[ ] Tap a photo tile: fullscreen viewer, X top-left, Download + white Share top-right; tap the image hides/shows the bars.
[ ] Download: toast "Saved to Pictures/XavierDrive"; image visible in Gallery. Check Android 9 or lower too (goes to app Pictures folder).
[ ] Share: system share sheet opens with the image (check cache/aiimg is readable through the FileProvider on a real device).
[ ] Files > pick a .txt: document tile with icon + extension + name; tap shows text; X removes.
[ ] Admin/dev: Generate image > result shows as a rounded card in chat (light + dark); tap opens the same viewer; Download/Share work.
[ ] Send with attachments still works (images + text) - the strip clears after send.


---
## STEP 6 UPDATE
Step 6 is done in code (see NEXT_AI_README.md, "STEP 6 - DONE"). `changed-files/` is cumulative for steps 1-6, patch is `steps-1-6.patch`
(`git apply --check` clean against repo main). Compiles against android-34 with stubs; still run build-apk.sh.

**Worker deploy (server/worker.js is CUMULATIVE: step 4 security + step 6 events; step-6-only diff = server/worker-step6-agentic-events.patch)**
- The app now calls /api/chat/stream with `agentic:true`. Old builds and the website are unaffected (they never send the flag), but a NEW app
  against an OLD worker just gets the old `step`/`answer` events: no text event, so it silently falls back to /api/chat (works, but no live rows).
  So the worker can be deployed before or after the app; deploy both before the release.
- The step-4 worker warnings still apply (test with a student cookie; BACKEND_KEY >= 16 chars; DEVELOPERS folder name).
- Smoke test after deploy: `curl -sN -X POST <worker>/api/chat/stream -H 'Content-Type: application/json' -H 'Cookie: <session>' -d '{"message":"latest CBSE news","agentic":true}'`
  expect `"t":"step"` (running/done), `"t":"summary"`, `"t":"text"`, `"t":"done"`. Without `"agentic":true` expect `"t":"step"` + `"t":"answer"` exactly as before.

**On-device checklist (step 6)**
[ ] Ask something that needs the web ("latest CBSE news"): the typing row turns into action rows (Searching the web, Reading ..., Composing answer),
    the active one pulses, a one-line summary appears between them, then the reply lands and a collapsed "N steps >" chip sits above it; tap opens/closes.
[ ] Small talk ("hi"): no chip stays after the reply.
[ ] "Make a bar chart of 5 subject marks": a native chart card appears (bar), also line and pie; light AND dark; rotate/reopen the chat: still there.
[ ] "Write my notes as a file": file card as before + a "Created <name>" row in the trail.
[ ] Airplane mode mid-request / Worker down: falls back to the JSON call or shows the normal error, never hangs beyond ~2 min.
[ ] Switch to another chat while it is answering: no crash, the reply lands in the original chat.


---
## STEP 7 UPDATE (Worker only - no app change, no new build needed for it)
Step 7 is done in code (see NEXT_AI_README.md, "STEP 7 - DONE"). `server/worker.js` is cumulative (steps 4+6+7); step-7-only diff = `server/worker-step7-router.patch`. Research numbers: `server/AI_LIMITS.md`.
**This step finally enforces the student limit (it never existed before) - read the deploy notes.**

**1. Backend change you must apply (backend/server.js in the xavier-drive repo; I could not see it)**
The Worker now adds `route: {tier, maxTier, difficulty, needsTools}` to the body it POSTs to `/ai/chat` and `/ai/chat/stream`. Wherever the backend calls the Worker's `/internal/ai/call`, add to that request body:
`tier: payload.route?.tier, maxTier: payload.route?.maxTier`, and for its planner / title / query-rewrite calls add `purpose: 'plan'` (routes them to the cheapest tier). Keep `messages`, `systemExtra`, `maxTokens` as they are.
Without this nothing breaks (the Worker applies its heuristic capped at 'standard'), but teachers never get 'pro' models through the backend and the classifier result is dropped. The response now also carries `tier`.

**2. Env / secrets (all optional, sensible defaults)**
STUDENT_DAILY_LIMIT (default 30; STUDENT_GEMINI_LIMIT still works as the fallback name), TEACHER_DAILY_LIMIT 300, ADMIN_DAILY_LIMIT 1000, DEV_DAILY_LIMIT 2000, STUDENT_MAX_TIER standard,
ROUTER_LLM_CLASSIFY (set "0" to disable the classifier call), ROUTER_LADDER_JSON (override model ids without redeploy), OR_FREE_DAILY (50; 1000 if the account bought $10 of credits), GROQ_TPM_LIMIT (8000).
Owner has NOT confirmed these numbers: 30/300/1000/2000 are defaults I chose.

**3. Verify BEFORE deploying**
[ ] Firebase RTDB accepts writes to `usage2/<email>/<YYYY-MM-DD>` from the Worker (rules + FIREBASE credentials; the owner says the service account is absent). Test: send 2 chats, read the node in the console - it must hold 2.
    If it stays empty the limit silently degrades to per-isolate memory (still returns 200).
[ ] `PUT {".sv":{"increment":1}}` works on your RTDB (should be standard). Refund path decrements by 1.
[ ] Student cookie: set STUDENT_DAILY_LIMIT=3 on a test deploy; the 4th message on BOTH /api/chat and /api/chat/stream returns HTTP 429 with `quotaExhausted:true`, and the app shows the message. Teacher cookie: not blocked.
[ ] `curl -s <worker>/api/quota -b '<student cookie>'` returns used/limit; `?role=teacher` in the query no longer changes anything.
[ ] Ask a student account "hi" -> admin health shows lastTierUsed=lite (Workers AI answered); "prove that root 2 is irrational step by step" -> tier standard for a student, pro for a teacher (needs item 1).
[ ] Long research question with Groq keys alive: no 413 in logs; `[ai-router] groq/... failed` lines should not appear for size reasons.
[ ] Confirm gemini-3.1-flash-lite is a valid model id for your key (one curl); if not, set ROUTER_LADDER_JSON.

**4. Owner-side (tell him)**
- Groq keys are dead; the router works without them (OpenRouter/Workers AI carry it). Groq's limits are per account, so 5 keys in one account are worth one key.
- Cheapest real upgrade: buy $10 of OpenRouter credit ONCE on one account -> 1,000 free-model requests/day (vs 5 accounts x 50) and drop the multi-account ToS risk. Then set OR_FREE_DAILY=1000.
