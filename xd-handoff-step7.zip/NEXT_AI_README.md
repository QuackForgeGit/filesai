# XavierDriveApp - NEXT_AI_README.md (read this fully first)
(There is also ZAI_README.md - that one is for the z.ai manager who builds, verifies and uploads. You update BOTH files every session.)

You are continuing a multi-session job with NO prior context. This file is your
whole briefing. Do ONE step per session, then update this README and re-zip
(see "HANDOFF PROTOCOL" at the bottom; there are 8 steps in total).

## 0. The project
- Native Android app (Java, NO Gradle, NO Kotlin, NO WebView features) for
  St. Xavier's Jr./Sr. School, Muzaffarpur. Package com.stxaviers.app.
  Build: build-apk.sh (aapt2 + javac + d8 + apksigner).
- Android app repo (public): https://github.com/StXaviersOfficial/stxaviers-android  (branch main, v1.1.6 code 19)
- Backend + website + Cloudflare Worker: https://github.com/StXaviersOfficial/xavier-drive
  (worker.js = auth/API/AI gateway, backend/server.js = Node backend, website-docs/ = 16 architecture docs,
  read 04-ai-chat.md and 05-ai-artifacts.md first)
- Roles: Student < Teacher < Admin < Developer (server-verified; never trust client role).
- Owner = "Quack" (student dev). Wants: premium, production-grade, publish-ready UI/UX; deep
  research; HONEST, BRUTAL reviews, no sugarcoating (swearing in his messages is normal, not hostile).
  He dictates by voice - interpret intent, not typos.

## Immutable laws (from the project's own brief)
- Version bumps exactly +0.0.1: next release is 1.1.7 / versionCode 20 (bump in AndroidManifest.xml
  AND VERSION= in build-apk.sh) - do the bump ONLY in the final step.
- Native only. Every screen must work in light AND dark (res/values-night).
- Students never see original filenames. AI must never leak admin info. English only.
- Chats persist at chats/{gmail}/{chatUid}/chat.json + artifacts/ workspace (ChatSync.java).
- Provider keys never leave the Cloudflare Worker.
- You have no Android SDK in most sandboxes: the owner's manager AI (z.ai) has a terminal and will
  compile with build-apk.sh. Still, keep code syntactically clean: run
  `javac -proc:none -d /tmp/o <files>` and make sure there are NO parse errors (ignore
  "cannot find symbol / package does not exist"). Validate every XML with a parser.

## 1. The owner's full wish list (the goal of all steps)
1. Premium redesign of EVERYTHING in the AI section; chat composer exactly like the Claude app.
2. "+" (far left of composer) opens 5 options: Camera, Photos, Files, Generate image, Deep research.
3. Mic icon like Claude's; while listening turns into a waveform; tapping again stops and
   transcribes; transcript is APPENDED to existing text, never replaces it.
4. Keyboard's bottom-right key = NEW LINE, never send.
5. Send = arrow, grey when empty, blue when there is text; box auto-grows/shrinks to a limit.
6. Hamburger drawer redesign; each chat row has a 3-dot menu (popup right there):
   Rename, Pin, Summarize chat; Teacher/Admin/Developer ALSO get Delete chat.
7. Chat itself like Claude: agentic steps (action row -> short summary -> action -> summary ...),
   AI can output artifacts, files, charts/visuals, and COPY BOXES (code-style block with one-tap copy).
8. Model routing: Students get the cheapest capable model even for agentic tasks. Available:
   Groq (keys currently DEAD), OpenRouter, Cloudflare Workers AI (10,000 neurons/day/account,
   resets 00:00 UTC), Gemini. The AI itself classifies task difficulty (easy/medium/hard) and the
   router picks the model accordingly, conserving tokens/quota. Research each provider's CURRENT
   free limits on the web first, then set per-role limits (student cap; teacher/admin/dev generous).
   Existing worker: STUDENT_GEMINI_LIMIT = 30 (env). Owner has not confirmed a new student cap yet -
   ASK him if you need it, else keep 30/day.
9. Speaker (TTS) button: while speaking shows Pause/Play state and highlights the exact word
   currently being spoken, advancing live (TtsPlayer.java exists).
10. Copy button under EVERY AI response and under user messages; on tap the icon becomes a tick
    (ic_check) briefly and the text is copied.
11. Attachments in composer = small square thumbnails in a horizontal row (new one appended to the
    right), each with a small X; tapping a thumbnail opens a full preview (see refs 3).
12. Generated images (Pollinations) appear in chat as rounded image cards (ref 4); tapping opens a
    fullscreen preview (ref 5) with Download + Share buttons at the top (ignore the Edit/Resize/
    Remove bottom bar in that screenshot).
13. Security fixes + full review (see step 6).

## 2. Reference images (folder reference-images/) - LOOK AT THEM
1 Claude app agentic chat: "Editing file >" action rows with a one-line summary between them.
2 Artifact card + ZIP file card rendered inside the chat, followed by a bullet summary.
3 Composer attachment thumbnails: small square chips in a row with an X badge.
4 Generated image inside a chat bubble (rounded, blank only because owner was offline).
5 Fullscreen image viewer: X top-left, three-dot + download + Share top-right.
6 Claude's "Capabilities" settings: shows the kinds of things Claude can do (web search,
  artifacts, inline visualizations, code execution + file creation) - our AI should match these.
7 Voice recording state of the composer: waveform bar with X (cancel), stop, and send buttons.

## 3. STATUS
| Step | Scope | State |
|---|---|---|
| 1 | Enter key = newline; mic appends (no overwrite); auto-grow limit 8 lines | DONE |
| 2 | "+" bottom sheet, waveform mic, arrow send button, Whisper-fallback typing bug | DONE |
| 3 | Drawer redesign + chat row 3-dot menu (Rename/Pin/Summarize/Delete-for-staff) | DONE |
| 4 | Message UI: copy button (tick), user-message copy, TTS play/pause + word highlight, copy boxes | DONE |
| 5 | Attachment thumbnails + image card + fullscreen preview (download/share) | DONE (not device-tested) |
| 6 | Agentic streaming events (step/artifact/chart/file) in worker.js+backend + renderer | DONE (not device-tested, worker NOT deployed) |
| 7 | Model router + difficulty detection + limits (research limits first) | DONE (worker only, unit-tested with mocks, NOT deployed, backend forwarding NOT applied) |
| 8 | Security fixes + final QA + version bump 1.1.7 (code 20) | **NEXT** |

## 4. What steps 1-3 changed (all included in changed-files/, patch = steps-1-6.patch (cumulative), made against repo main v1.1.6)
- res/layout/activity_ai.xml: ai_input now flagNoEnterAction (Enter = newline), min 1 / max 8 lines,
  send icon = ic_arrow_up (20dp, muted grey when empty).
- src/.../AiActivity.java: send-on-Enter listener removed. Mic: `voiceInserted` logic appends
  dictation to the CURRENT box text (swaps only its own previous partial), so typed text and text typed
  during recording survive. Listening UI = animated WaveformView inside the mic button on the blue circle.
  showPlusMenu() rewritten from PopupWindow to a bottom-sheet Dialog (handle, 44dp icon tile, title +
  subtitle, tick when Deep research/Generate image active). `plusMenu` is now a Dialog.
  Generate image row is STILL shown only to admins/devs (existing owner rule, st.adminPower()). If the
  owner wants students to see it too, remove the `if (i == 3 && !power) continue;` line - ask him.
- NEW src/.../WaveformView.java (canvas bars, start()/stop()).
- NEW drawables: ic_arrow_up, sheet_bg, sheet_handle, sheet_icon_bg; CHANGED ai_send_idle (grey circle),
  ai_send_ready (solid brand blue instead of gradient).
- res/values/strings.xml: 6 new strings (ai_sheet_*). No night overrides needed (uses home_* colours which
  already have values-night versions).
- STEP 3: AiActivity.rebuildDrawer() rewritten: sections Pinned / Today / Yesterday / Previous 7 days / Older
  (by session created time, helper sectionOf()/addSectionHeader()), flat 46dp rows with title only, active row =
  tonal fill, 3-dot is a 40dp ripple touch target at the far right. showChatMenu() rewritten: 208dp anchored
  popup (popup_menu_bg), right-aligned under the dots, flips above if no room; Rename, Pin/Unpin, Summarize
  (blocked with a toast while the AI is busy), and Delete ONLY when st.teacherPower() (Teacher/Admin/Developer)
  - Delete is HIDDEN for students, not just blocked. Long-press on a row opens the same menu.
  New drawables chat_row_bg/chat_row_on (rounded 12dp, borderless - replaced the old square bordered ones),
  popup_menu_bg; new strings ai_section_*, ai_busy_wait, ai_more_cd.
- Pins are stored per-device (persistCache), not synced to the server. Summarize sends a normal chat message
  into that chat (existing behaviour kept). Both are acceptable for now - mention only if the owner asks.
- NOT compiled or run by the author (no SDK). Parse-checked only, and every R.string/R.color/R.drawable
  referenced by AiActivity was checked to exist. z.ai must build and fix any symbol errors.
- CRITICAL SERVER FINDING (not fixed yet - step 8, also in ZAI_README): worker.js `DELETE /drive/delete?id=`
  only requires ANY valid session; it then deletes with the OWNER's Drive token. So a student can delete any
  Drive file they know the id of, even though the app hides Delete. Must add a role check (teacher tier) and
  ideally verify the id is inside the caller's own chats folder or a teacher-managed folder.

## 5. STEP 8 - do this now (security leftovers + QA + release)
Steps 4 already fixed: HTML-preview WebView sandbox, Drive role checks, constant-time X-Backend-Key. Do NOT redo those. Left:
- worker.js `rateCheck` (20/min chat etc.) is in-memory per isolate -> useless across isolates. Move to a Durable Object (SQLite-backed DOs are on the
  Workers Free plan) or, if that is too big, at least document it. Do NOT use KV for counters: Workers Free KV = 1,000 writes/day for the whole account and sessions need them.
- Students can still list the whole Drive via arbitrary queries and create files anywhere (step 4 "known, not fixed"): restrict `q` to the caller's folders.
- Verify what step 7 could not: (a) the Firebase RTDB quota path works with the current rules/credentials (owner says the service account is absent; if writes are
  rejected the counter silently falls back to per-isolate memory = weak limit; check `usage2/` rules, or move the counter to a Durable Object), (b) the backend really forwards
  route.tier (see ZAI_README step 7), (c) `PUT {".sv":{"increment":1}}` returns the new number on the live DB (the code copes if it does not).
- Full read-through of AiActivity.java (2400+ lines) for bugs, especially code from steps 1-3 that was never reviewed (drawer, chat menu, plus sheet).
- App: show the quota. The Worker now returns quotaUsed/quotaLimit on /api/chat and in the stream `done` event, and HTTP 429 {error, quotaExhausted, resetAt}
  when the daily limit is hit (the app already shows the 429 message; a small "12/30 today" chip is optional polish).
- Ask the owner: (1) student cap - kept at 30/day, teacher 300, admin 1000, developer 2000 (my guesses, all env-tunable, see step 7 notes); (2) should students see "Generate image" (one line, section 4);
  (3) buy the one-time $10 OpenRouter credit on ONE account and set OR_FREE_DAILY=1000 (see server/AI_LIMITS.md).
- Owner action list to repeat in the final message: publish the OAuth consent screen (Testing mode = 100 users cap, 7-day refresh expiry), YouTube API key renewal, Firebase service account,
  5-accounts-per-provider ToS risk, Groq keys dead.
- Bump version to 1.1.7 / versionCode 20 in AndroidManifest.xml AND VERSION= in build-apk.sh; final README pass; final checklist for z.ai.
Deliver as per HANDOFF PROTOCOL (README x2, cumulative changed-files/, steps-1-8.patch, zip).

## 6. Later steps
None - step 8 is the last.

## 7. HANDOFF PROTOCOL (mandatory, every session)
1. Work on the repo (clone main, apply steps-1-2.patch and any later patches, or copy changed-files/ over it).
2. Do exactly the NEXT step only. If you still have capacity afterwards the owner will tell you to continue.
3. When finished: (a) update section 3 status table, ZAI_README.md (add what z.ai must build/verify/deploy for your step), section 4 (append what you changed), and section 5
   (rewrite it as the detailed spec of the following step, moving that step's short spec out of section 6);
   (b) rebuild changed-files/ so it contains the CUMULATIVE full versions of every file changed in
   steps 1..N, regenerate the patch as steps-1-N.patch (delete the old patch file), keep reference-images/ untouched;
   (c) zip the whole folder and give it to the owner with a 5-line summary of what changed and what is untested.
4. Be honest about anything not verified. Never claim something was tested if it was not.


---
## STEP 4 — DONE (v1.1.7 work, compiled but NOT device-tested)

Compiled clean against a real API 34 android.jar (stub R.java) with steps 1-4 applied. Never run on a phone.
`changed-files/` is now CUMULATIVE (steps 1-4) and `steps-1-4.patch` is the full diff vs the repo's v1.1.6.

**What step 4 added**
- Copy button turns into a tick for ~1.5 s (AI and user messages; user rows have a new copy button).
- Listen button: Pause / Resume, one message speaks at a time, live word highlight (estimated on cloud voice, exact via onRangeStart on device voice, Android 8+). `TtsPlayer` rewritten; old `State` API kept for the voice preview in AiSettingsActivity.
- Copy boxes: ```copy and ordinary code fences render as bordered boxes with their own Copy button (`Ui.segments()` + `AiActivity.buildAiBody/buildCodeBox`). Code is never read aloud.
- `Ui.formatAi` rewritten: real bullets for "* item" / "- item", no 63-bold-span cap, leftover fences shown as plain text. ```chart / ```file / ```pdffile still show a one-line note (steps 5/6).
- New files: ic_pause.xml, ic_tick.xml, copybox_bg.xml; strings ai_pause, ai_resume, ai_copybox_label; item_msg_ai.xml gets bubble_body + act_copy_icon.

**Security fixes**
- App: HTML preview WebView sandboxed (CSP, no network, no file/content access, no navigation).
- Worker (`server/worker.js` + `server/worker-step4-security-and-copybox.patch`, NOT deployed): Drive routes now check the caller's role. Students may only modify/delete/rename/move inside CHATS/<own email>; mkpub and POST /drive/files are staff-only; students cannot download other users' chats or TEACHERS/ADMINS/DEVELOPERS folders; Drive ids and upload metadata validated; X-Backend-Key check is fail-closed and constant-time (BACKEND_KEY must be >=16 chars or the backend gets locked out); dev-login secret must be >=24 chars.
- Worker system prompt now tells the AI to use ```copy blocks.

**Before deploying the worker**: test with a student cookie (chat save/delete still works, other folders 403), confirm BACKEND_KEY length, confirm a DEVELOPERS folder name matches.

**Known, not fixed**: students can still list the whole Drive via arbitrary queries and create files anywhere; rate limits are in-memory; website lets students delete chats while the Android app hides Delete; updater has no explicit https-only guard (OS signature check + cleartext ban cover it); drawer / chat menu / plus-sheet code was not reviewed; "generate image admin-only" question still open.

**Next: step 5** (charts) and step 6 (file / pdffile blocks), per the roadmap above.


---
## STEP 5 — DONE (compiled, NOT device-tested)
Overlaid on the repo (v1.1.6 main) and compiled with javac against a real API 34 android.jar (stub R + stub FileProvider):
AiActivity.java and Ui.java produce zero errors. The only errors left are in files I did not touch (LoginActivity,
NativeGoogleSignIn, GlowCardView, FabricSpaceView) and come from missing Google/androidx libs in my stub setup, not from this step.
All XML parses. Never run on a phone.

**What step 5 added**
- Composer strip (AiActivity.refreshAttachStrip): 64dp rounded square tiles, near-black X badge (att_badge_bg) top-right,
  new tile appended right and scrolled into view. Photo tap -> fullscreen viewer. Document tile (icon + extension + name, att_tile_bg)
  tap -> text preview of the extracted text.
- Generated image card in chat: item_msg_ai bubble_img is now a rounded card (img_card_bg, clipToOutline, max 320dp x 420dp)
  instead of the padded rectangle; tap opens the viewer (used to open the system viewer).
- Fullscreen viewer showImageViewer(bmp, file, name): X top-left; Download (round) + white "Share" pill top-right; tap the picture
  toggles the bars. showFullImage(bmp) kept as a wrapper, and the AI-emitted base64 image path uses the same viewer.
  Download = Ui.saveToPictures (NEW): MediaStore Pictures/XavierDrive on API 29+, app Pictures folder below. Original file bytes when
  known, else JPEG 95 / PNG. Share = temp copy in cache/aiimg + FileProvider (cache-path "." in file_paths.xml already covers it) + chooser.
- New: drawables att_badge_bg, att_tile_bg, viewer_btn_bg, viewer_share_bg, img_card_bg; 7 strings ai_viewer_* / ai_att_remove_cd.

**Not done / known**
- No pinch-zoom or pan in the viewer (spec said optional). The Edit/Resize/Remove bar from ref 5 is intentionally absent (owner said ignore).
- Sent user messages still show "[Attached: name]" text, not thumbnails - the owner's list only asked for the composer strip.
- Documents are read as UTF-8 text, so a PDF/DOCX tile previews as garbage; pre-existing, only more visible now.
- Generated images live in cache/aiimg, so they can vanish if Android clears the cache (the Drive copy still exists).
- Worker changes from step 4 are still undeployed (see ZAI_README).


---
## STEP 6 — DONE (compiled, NOT device-tested, Worker NOT deployed)
Overlaid on repo main (v1.1.6) and compiled with javac against a real API 34 android.jar (stub R + stub FileProvider): AiActivity,
Ui, ApiClient, AgentTrail, ChartView produce zero errors (remaining errors are only in files I did not touch and are missing-library
noise from my stub setup). All XML parses. Worker helpers unit-tested in node; worker.js passes `node --check`. The stream path itself
(worker -> app) was NOT exercised end to end: no backend, no device.

**Finding that shaped the design:** the Android app never streamed. It POSTed /api/chat (one JSON reply) and showed a cycling
"Thinking..." label. So step 6 = worker typed events + a new streaming call in the app + UI to render them.

**Worker (server/worker.js, patch = server/worker-step6-agentic-events.patch, on top of the step-4 worker)**
- handleAIChatStream: when body.agentic === true it emits typed events instead of the website format:
  `step {id,title,detail,icon,status:running|done}`, `summary {text}`, `artifact {name,type:file|pdf|html,mime}`,
  `text {delta}`, `done {provider,searched,sources}`. Without the flag it emits exactly the old `step`/`answer` events (website unchanged).
- `summary` lines are TEMPLATED from the finished step ("Searched the web for ...", "Read <site>."), not written by an LLM: free, but plain.
- `text` carries the WHOLE answer in one event: the backend engine returns the answer whole, there is no token stream to forward.
- backend/server.js NOT changed: it already emits the step events; translating in the Worker keeps one deploy.
- Deviations from the original spec (deliberate): (1) no `chart` event - the ```chart block stays in the answer text and the app draws
  it from there, so charts survive reload and the website keeps working; (2) no `file {id,url}` event - files are not stored server-side,
  the ```file block stays in the text (the app already builds cards + stores them in the workspace); `artifact` is only metadata for the
  "Created notes.md" action row.

**App**
- ApiClient.streamSse (NEW): POST + read text/event-stream, 130 s read timeout. AiActivity.requestAnswer now streams
  /api/chat/stream with agentic:true; if the stream yields no text it falls back to the old /api/chat JSON call (keeps the quotaExhausted
  warning), and 429 shows the server message.
- AgentTrail.java (NEW): live rows (icon + title + one-line detail, pulsing while running, tap a row to open its detail) with the summary
  line between them, inside the typing row. When the reply lands the trail is kept as a collapsed "N steps >" chip above the reply
  (only if a search / read / file happened) - NOT persisted, it is gone after the chat is reopened.
- ChartView.java (NEW): native Canvas bar / line / pie from the ```chart block (labels + datasets|series, max 12 labels, 4 series),
  light + dark via home_* colours. Ui.segments now returns chart blocks as a segment; AiActivity.buildChartCard draws it in a card with
  the chart's title; an undrawable spec shows one quiet note line (string ai_chart_failed).
- Untouched on purpose: ```file / ```pdffile cards (already existed), image viewer, everything from steps 1-5.

**Not done / known**
- No Download-PNG button on charts (the website has one). Charts are not tappable/zoomable.
- Artifact "card" styling from ref 2 is the existing file card, not a new design. The action-row look is my reading of ref 1.
- Stream path has no quota check and no memory update (see step 7 note above). The 429 rate limit (20/min) is still per-isolate memory.
- If the user switches chats mid-answer the live rows are dropped (the reply still lands in the right chat).


---
## STEP 7 - DONE (Worker only; unit-tested with mocks, NOT deployed, NOT run against live providers)
No app changes: changed-files/ and the app patch are unchanged (steps-1-7.patch is the old steps-1-6 content, renamed). Server work: `server/worker.js` is CUMULATIVE
(steps 4+6+7); the step-7-only diff is `server/worker-step7-router.patch`. `node --check` clean; 17 mock tests pass (difficulty heuristic, tier clamps, ladders, role profiles,
quota incl. an atomic Firebase fake and a 5-way parallel burst, router order/model-on-the-wire, oversize prompt, classifier + fallback). Research + sources: `server/AI_LIMITS.md`.

**Research findings that changed the design**
- Groq limits are per ORGANISATION and its 8k TPM is charged for the DECLARED `max_tokens`. Old code sent 4096 + up to ~6k tokens of research context => 413 on every research answer, and each failure tripped
  the 10-minute Groq circuit breaker for everybody. Now: max_tokens is capped to (8000 - estimated prompt), a prompt too big for the window skips Groq WITHOUT tripping the breaker, 413 handled. (GROQ_TPM_LIMIT env if you upgrade Groq.)
- OpenRouter is per ACCOUNT (extra keys add nothing): 20/min, 50/day, or 1,000/day after a lifetime $10 purchase. Gemini free is tiny and unpublished (~20/day for 3.8-flash, reported). Cloudflare 10k neurons/day/account, glm-4.7-flash ~270k output tokens.
- **The student limit did not exist.** `incrementQuota` was never called anywhere, `quotaUsed` was hard-coded 0, and the stream path had no check. STUDENT_GEMINI_LIMIT=30 was decoration.

**What step 7 added (all in worker.js)**
- Difficulty: free heuristic first (greeting/short lookup = easy; code/proofs/algorithms = hard); only unsure cases (~"medium") ask a tiny LLM call on the cheapest tier (JSON {difficulty, needs_tools}, 5 s timeout, cached, falls back to the heuristic;
  ROUTER_LLM_CLASSIFY=0 turns the LLM call off). easy->lite, medium->standard, hard->pro.
- Ladders per provider per tier (ROUTE_LADDER; override with env ROUTER_LADDER_JSON). Students are capped at 'standard' (STUDENT_MAX_TIER) so they never reach gpt-oss-120b / nemotron / etc. Teachers, admins, developers get 'pro'.
  'lite' tries Workers AI first; standard/pro keep the owner's order Groq -> OpenRouter -> CF -> Gemini. Image questions below 'pro' use Gemini flash-lite to save the scarce 3.8-flash quota.
  Removed inclusionai/ling-3.0-flash-sante:free from OpenRouter; added gemma-4-26b-a4b and nemotron-3-ultra.
- Limits: students 30/day (STUDENT_DAILY_LIMIT, falls back to STUDENT_GEMINI_LIMIT), teacher 300, admin 1000, developer 2000 (TEACHER/ADMIN/DEV_DAILY_LIMIT). Day = IST, resets 00:00 IST. Role comes from verifyRole, never from the client
  (`/api/quota` used to trust ?role= from the query string). One message is reserved BEFORE the call and refunded if the whole request fails. Enforced on /api/chat AND /api/chat/stream; HTTP 429 {error, quotaExhausted, quotaUsed, quotaLimit, resetAt}.
  Store: Firebase RTDB `usage2/<email>/<IST day>` with server-side increment; falls back to per-isolate memory if Firebase is unreachable (weak, logged). Old `/usage/` node unused.
- OpenRouter daily cap now env OR_FREE_DAILY (default 50). `/internal/ai/call` accepts optional {tier, maxTier, purpose}; without them it applies the heuristic capped at 'standard'.
- Admin health output now shows the ladder and lastTierUsed.

**Not done / known**
- The backend engine (backend/server.js, not in this zip) makes the actual LLM calls through /internal/ai/call and I could not edit it. The Worker sends `route:{tier,maxTier,difficulty,needsTools}` to it; until the backend forwards
  `tier`/`maxTier` (2-3 lines, ZAI_README), unknown traffic gets the heuristic capped at 'standard' => students are safe, but teachers/admins never reach 'pro' via the backend path and the classifier result is ignored there.
- The classifier adds one LLM call to unsure messages on top of the backend's own planner + answer calls; watch quotas, turn off with ROUTER_LLM_CLASSIFY=0.
- Gemini 3.1 flash-lite id unverified; Gemini limit numbers are low-confidence. Heuristic thresholds are my judgement, never tuned on real traffic.
- Quota counts messages, not tokens or "hard" requests; a chat with web research still counts as 1.
