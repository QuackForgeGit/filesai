# Round 2 fixes for crazysmp-website

## 1. Rank icons were showing the wrong rank
GLM built this without vision, so it just guessed which generated image
file matched which rank name — and got 4 of them shuffled:

| File            | Was labeled  | Actually contains |
|------------------|--------------|--------------------|
| pkg-vip.png      | VIP          | "LEGEND"           |
| pkg-legend.png   | LEGEND       | "Crazy"            |
| pkg-immortal.png | IMMORTAL     | "VIP"              |
| pkg-crazy.png    | CRAZY        | "IMMORTAL"         |

TITAN and TECHNO were already correct. Fixed by rotating the actual file
contents so each filename now matches what's drawn inside it — no code
changes needed since `page.tsx` already referenced them by the (correct)
rank-based filenames.

## 2. Logo was the wrong logo
`store-logo-new.webp` was a flat wordmark with no island. Replaced it with
the End-island version you sent (compressed to ~200KB webp, 900px).

## 3. Login screen boxes were badly misaligned
The old code had comments like "coordinates from VLM analysis" with guessed
percentages (e.g. username box at top:71%) that didn't match the image at
all (real position: top:54.4%) — again, a no-vision guess.

I re-measured all three boxes directly from `login-bg.png`'s actual pixel
data (sampling exact color transitions, not eyeballing), so the overlays
now line up pixel-for-pixel with the crystal-bordered boxes in the
background art. I tested this by rendering the page in a real browser and
screenshotting it — the overlays sit exactly on the drawn boxes now.

While rebuilding it I also did what you asked for each box:
- **Username box**: the *entire* box is now clickable (tested: clicking
  near the head icon, not just directly on the input, focuses it).
  Input only allows letters/digits/underscore — spaces and symbols are
  silently stripped as you type, capped at 16 characters (the real
  Minecraft username limit).
- **Bedrock toggle**: added a real green pill switch on the right side of
  the bar (whole bar also toggles it, common UX pattern). Turning it on
  prepends a `.` to the username live; turning it off strips it. Toggling
  on when a dot is already there doesn't add a second one (tested this
  exact sequence: on → off → on again stays at one dot).
- **Continue button**: entire box is clickable, "CONTINUE" text now
  renders in a chunky glowing font (white core + magenta glow, matching
  the LOGIN text style in the background art) instead of a plain sci-fi
  font that didn't fit.

## 4. Pricing
You said you'll send the real prices later, so I left the placeholder
values (₹199 / ₹399 / etc.) as-is rather than invent numbers that would
just get replaced. Ping me with the real ones whenever and I'll drop them
straight into the `PACKAGES` array in `page.tsx`.

## How to apply
Copy everything from `public/` and `src/app/page.tsx` in this folder over
your existing files (same paths), or `git apply page-diff.patch` for the
code change and manually copy the 5 replaced image/webp files.
