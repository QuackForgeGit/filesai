# Round 7: scroll-zoom fix + layered login system

## 1. Fixed the "zooms in on scroll" bug
Root cause: `.csmp-bg-fixed`/`.csmp-bg-overlay` used `position:fixed; inset:0`.
On mobile Chrome, that resizes as the URL bar collapses during scroll,
which made `background-size:cover` recompute — looked like a zoom.
Fixed: `top:0; left:0; width:100vw; height:100svh` instead — svh is
pinned to the smallest possible viewport, never resizes. Verified: bg
element height measured identical (900px) before and after scrolling.

## 2. Login page rebuilt as layered composition (mobile)
Used your 5 new images (bare sky, floating island, and 3 separate button
bars split out of your sheet) instead of one flat baked-in image. No
more cover-fit math needed — each layer just sizes itself:
sky = CSS background-size:cover, island + bars = plain `<img>`s in a
centered flex column, each bar's own input/toggle/button overlaid via
`position:absolute inset:0` on top of it. Tested: fill username, toggle
Bedrock (dot added correctly), Continue → saves to localStorage and
redirects to /store.

Desktop login untouched — still uses the existing baked composite +
contain-fit + border from Round 6.

## Not done this round (ran out of turns)
The aspect-ratio-distance-based mobile/desktop switch (comparing actual
viewport ratio to both images instead of a flat 900px width breakpoint)
— still on the old width breakpoint. Included in the prompt doc below if
you want another AI to pick it up, or I can do it next round.

## How to apply
Copy the 5 new images into `public/`, replace `src/app/login/page.tsx`
and `src/app/store/page.tsx`.
