# Round 8 fixes — all tested with real browser screenshots, not just built

## 1. Cards were clipped ("shaved heads") — FIXED
Root cause: someone added `overflow:hidden` on `.csmp-card-stack` to stop
sideways page scroll, which also clipped the 3D-tilted peeking cards
(their rotated/translated bounding boxes extend past that container).
Fixed: removed it, added `overflow-x:hidden` on `html, body` instead —
stops page-level sideways scroll without touching the cards. Verified:
`scrollWidth > clientWidth` is `false`, and a full-page screenshot shows
every card completely intact top-to-bottom.

## 2. Scroll "zoom" bug — re-fixed (was rolled back)
Same fix as before: `.csmp-bg-fixed`/`.csmp-bg-overlay` use
`top:0;left:0;width:100vw;height:100svh` instead of `inset:0`, so mobile
Chrome's URL-bar-collapse-on-scroll doesn't resize the background.
Verified: background height measured identical before/after scrolling.

## 3. Landscape mode breaking (rotated/sideways text) — FIXED
This was a symptom of the old box-position-math system breaking down at
unusual aspect ratios. Fixed by finishing the desktop rebuild: desktop
login now uses the same layered system as mobile (separate bg + floating
island + 3 bar overlays) instead of one flat baked image with fragile
coordinate math. Tested at 844×412 (a phone rotated sideways) — now
correctly picks the desktop layered layout via the existing
aspect-ratio-distance switch, renders cleanly, no rotated text.

## 4. Desktop login now has the same separated bg+overlay system as mobile
Used `/front-bg-desktop.webp` (already in the repo — a bare landscape
night scene with no island or buttons baked in) as the desktop sky layer,
paired with the same `login-island.webp` + 3 bar images as mobile, just
sized up. This is a genuine improvement over the old approach too — full
bleed cover, no letterbox border needed anymore.

## 5. Login island animation
Added a breathing scale (1 → 1.035) + purple glow pulse, matching the
main page logo's existing `portalGlow` animation style. Applied to both
mobile and desktop island.

## 6. "BEDROCK ACCOUNT" label restored
This text got stripped from the bar image in a GPT edit. Added back as
real text (not baked into the image) on both mobile and desktop, so it
can be positioned/styled independently.

## 7. Bedrock toggle shifted left (mobile)
Was pinned to `marginLeft:80%`, sitting right at the bar's edge. Now
flows naturally after the new label text with `marginLeft:auto` — sits
with proper breathing room from the edge.

## 8. Real Minecraft font, self-hosted
Extracted your `minecraft-font.zip` (4 files: Regular/Bold/Italic/
BoldItalic), converted OTF→WOFF2 (smaller, faster), added proper
`@font-face` rules in `globals.css`. Removed the old
`fonts.cdnfonts.com` `@import`/`<link>` hack from every file that had it
(layout.tsx, store/page.tsx, login/page.tsx, card-section.tsx) — one
source of truth now. Confirmed via `document.fonts.check()` that it
actually loads. Since `MC` and `USERNAME_FONT` already referenced
`'Minecraft'`, every existing usage (username, IP, credits, headings)
picked up the real font automatically with no per-usage changes needed.
Also confirmed the real font has full lowercase glyph coverage, so
usernames display correctly.

## 9. "IP copied" toast
Added a small toast at the bottom of the screen ("✓ IP copied!") that
appears for ~1.8s when you click the IP text or the Minecraft icon.
Tested — shows up correctly on click.

## How to apply
Copy `public/fonts/*.woff2` into `public/fonts/`, and replace:
`src/app/login/page.tsx`, `src/app/store/page.tsx`,
`src/app/globals.css`, `src/app/layout.tsx`,
`src/components/card-section.tsx`, `src/components/server-stats.tsx`
