# CrazySMP Store Page

## What's in here

- `standalone/CrazySMPStore.jsx` — single-file version, images baked in as
  base64. Drop it anywhere and it just works (used for the Claude preview).
- `src/CrazySMPStore.jsx` — clean version that imports the images normally.
  Use this one in the actual project.
- `assets/crazysmp-logo.webp` — your logo, compressed for web (500px, ~60KB)
- `assets/crazysmp-bg.webp` — your night-sky background, compressed (~79KB)

## Using it in your repo (crazysmp-website)

1. Copy `assets/*.webp` into your project's `src/assets/` folder.
2. Copy `src/CrazySMPStore.jsx` into your `src/` (or `components/`) folder.
   If your assets folder isn't a sibling of where you place this file,
   fix the two import paths at the top.
3. Install the one dependency it needs: `npm install lucide-react`
4. Import and render it, e.g. in `App.jsx`:
   ```jsx
   import CrazySMPStore from "./CrazySMPStore";
   export default function App() {
     return <CrazySMPStore />;
   }
   ```

## Notes

- Package names/prices (Obsidian, Wither, Ender ranks + Shard bundles) are
  placeholders — I made these up since you hadn't given real ones. Edit the
  `PACKAGES` array near the top of the component to swap in your actual
  ranks, bonuses, and prices.
- Package icons are dashed placeholder boxes since no rank artwork was
  provided — drop real images into `PackageIconPlaceholder` (or just an
  `<img>`) once you have them.
- Fonts (Baloo 2 + Nunito) load from Google Fonts via `@import` in the
  `<style>` block — make sure that's allowed wherever you deploy this.
- Tapping a package opens the "enter your username" bottom sheet, matching
  the reference site's flow.
